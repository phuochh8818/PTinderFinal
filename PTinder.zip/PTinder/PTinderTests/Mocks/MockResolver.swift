//
//  MockResolver.swift
//  PTinderTests
//
//  Created by Huynh Hong Phuoc on 12/16/20.
//

import Foundation
import XCTest

@testable import PTinder

class AppDataRepositoryImplDependencyResolverSpy : AppDataRepositoryImplDependencyResolver {
    lazy var coreDataStack: CoreDataStack =  {
        return TestCoreDataStack()
    }()
}
