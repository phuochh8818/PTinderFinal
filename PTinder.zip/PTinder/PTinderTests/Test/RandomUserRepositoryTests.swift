//
//  RandomUserRepositoryTests.swift
//  PTinderTests
//
//  Created by Huynh Hong Phuoc on 12/16/20.
//

import XCTest
import RxSwift
import RxBlocking
@testable import PTinder

class RandomUserRepositoryTests: XCTestCase {
    
    var testObject: RandomUserRepository!
    var disposeBag: DisposeBag!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        self.disposeBag = DisposeBag()
        self.testObject = RandomUserRepositoryImpl()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        self.disposeBag = nil
        self.testObject = nil
    }

    func testGetRandomUserApiCall() throws {
        let x = try testObject.get().toBlocking(timeout: 10).first()?.count
        
        XCTAssertEqual(x, 50)
    }
}
