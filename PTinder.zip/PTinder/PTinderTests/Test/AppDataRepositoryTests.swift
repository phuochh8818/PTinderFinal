//
//  AppDataRepositoryTests.swift
//  PTinderTests
//
//  Created by Huynh Hong Phuoc on 12/16/20.
//

import XCTest
import RxSwift
import RxBlocking
@testable import PTinder

class AppDataRepositoryTests: XCTestCase {
    
    var appDataRepositoryImplDependencyResolverSpy: AppDataRepositoryImplDependencyResolverSpy!
    var testObject: AppDataRepository!
    var disposeBag: DisposeBag!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        self.appDataRepositoryImplDependencyResolverSpy = AppDataRepositoryImplDependencyResolverSpy()
        self.testObject = AppDataRepositoryImpl(injecting: appDataRepositoryImplDependencyResolverSpy)
        
        self.disposeBag = DisposeBag()
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        self.disposeBag = nil
        self.testObject = nil
    }
    
    func testAllUsers() throws {
        let x = try testObject.getLikedUsers().toBlocking(timeout: 10).first()
        
        XCTAssertNotNil(x)
    }
    
    func testAddUser() throws {
        let newUser = User(gender: "M", name: Name(title: "Senior iOS Developer", first: "Phuoc", last: "Huynh"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil)
        let result = try self.testObject.like(user: newUser).toBlocking(timeout: 10).first()
        
        XCTAssertTrue(result?.lastName == "Huynh")
        XCTAssertTrue(result?.firstName == "Phuoc")
    }
    
    
    func testValidateOnAdd() throws {

        let newUser = User(gender: "N/A", name: Name(title: "Culi", first: "Xavi", last: "Bi"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: nil, nat: nil)
        
        do {
            _ = try self.testObject.like(user: newUser).toBlocking(timeout: 10).single()
            XCTFail()
        }
        catch AppError.invalidData {
            
        }
        catch let e {
            XCTFail(e.localizedDescription)
        }
    }
    
    func testValidateOnAdd2() throws {

        let newUser = User(gender: "M", name: nil, location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil)
        
        do {
            _ = try self.testObject.like(user: newUser).toBlocking(timeout: 10).single()
            XCTFail()
        }
        catch AppError.invalidData {
            
        }
        catch let e {
            XCTFail(e.localizedDescription)
        }
    }
    
    func testValidateOnAdd3() throws {

        let newUser = User(gender: "M", name: nil, location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: nil, nat: nil)
        
        do {
            _ = try self.testObject.like(user: newUser).toBlocking(timeout: 10).single()
            XCTFail()
        }
        catch AppError.invalidData {
            
        }
        catch let e {
            XCTFail(e.localizedDescription)
        }
    }
    
    func testGetAllUsers() throws {
        let users = [
            User(gender: "M", name: Name(title: "Code Dạo", first: "Phuoc", last: "Huynh"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil),
            User(gender: "M", name: Name(title: "Senior Tracker", first: "Long", last: "Ma"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil)
        ]
        
        let expect = users.count
        
        for user in users {
            _ = try self.testObject.like(user: user).toBlocking(timeout: 10).first()
        }
        
        let actual = try testObject.getLikedUsers().toBlocking(timeout: 10).first()?.count
        
        XCTAssertEqual(actual, expect)
        
    }
    
    func testDeleteWhenNoElement() throws {
        let newUser1 = User(gender: "M", name: Name(title: "Code Dạo", first: "Phuoc", last: "Huynh"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil)
        _ = try self.testObject.like(user: newUser1).toBlocking(timeout: 10).first()
        
        let dbBeforeDelete = try testObject.getLikedUsers().toBlocking(timeout: 10).first()
        
        XCTAssertEqual(dbBeforeDelete?.count, 1)
        let userToDelete = dbBeforeDelete![0]
        _ = self.testObject.delete(user: userToDelete)
        _ = self.testObject.delete(user: userToDelete)
        _ = self.testObject.delete(user: userToDelete)
        
        let dbAfterDelete = try testObject.getLikedUsers().toBlocking(timeout: 10).first()
        let actual = dbAfterDelete!.count
        
        XCTAssertEqual(actual, 0)
    }
    
    func testDeleteAUser() throws {
        let users = [
            User(gender: "M", name: Name(title: "Code Dạo", first: "Phuoc", last: "Huynh"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil),
            User(gender: "M", name: Name(title: "Senior Tracker", first: "Long", last: "Ma"), location: nil, email: nil, login: nil, dob: nil, registered: nil, phone: nil, cell: nil, picture: Picture(large: "nil", medium: "nil", thumbnail: "nil"), nat: nil)
        ]
        
        let tasks = users.map { self.testObject.like(user: $0) }
        
        _ = Observable.zip(tasks).toBlocking(timeout: 10)
        
        let dbBeforeDelete = try testObject.getLikedUsers().toBlocking(timeout: 10).first()
        XCTAssertEqual(dbBeforeDelete?.count, 2)
        let userToDelete = dbBeforeDelete![0]
        _ = self.testObject.delete(user: userToDelete)
        let dbAfterDelete = try testObject.getLikedUsers().toBlocking(timeout: 10).first()
        let actual = dbAfterDelete!.count
        
        XCTAssertEqual(actual, 1)
    }
}
