//
//  TDControlView.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit
import RxRelay

let inset : CGFloat = 2
let buffer = 3
let sepeatorDistance : CGFloat = 8


/// TDControlView is container view for all stack card, manage all card and user behavior, output thru likePublishRelay, dislikePublishRelay
public class TDControlView : UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.prepareView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    private var models = Queue<User>()
    private var loadedCards = [TDCardView]()

    var likePublishRelay = PublishRelay<User>()
    var dislikePublishRelay = PublishRelay<User>()
    
    func loadMore(models: [User]) {
        self.models.enqueue(contentsOf: models)
        
        for (_,model) in models.enumerated() {
                    
            if loadedCards.count < buffer {
                
                let cardView = self.createNewCard(viewModel: .Real(model: model))
                if loadedCards.isEmpty {
                    self.addSubview(cardView)
                } else {
                    self.insertSubview(cardView, belowSubview: loadedCards.last!)
                }
                loadedCards.append(cardView)
            }
        }
        
        animateCardAfterSwiping()
    }
    
    fileprivate func popCard() {
        if let m = models.dequeue() {
            self.removeCardAndAddNewCard(viewModel: .Real(model: m))
        } else {
            self.removeCardAndAddNewCard(viewModel: .Loading)
        }
    }
    
    fileprivate func removeCardAndAddNewCard(viewModel: CardViewModel){
        loadedCards.remove(at: 0)
            
        let tinderCard = self.createNewCard(viewModel: viewModel)
        self.insertSubview(tinderCard, belowSubview: loadedCards.last!)
        loadedCards.append(tinderCard)
        
        animateCardAfterSwiping()
    }
    
    fileprivate func createNewCard(viewModel: CardViewModel) -> TDCardView {
        
        let frame = CGRect(x: inset, y: inset,
                           width: self.bounds.width - 2*inset,
                           height: self.bounds.height - CGFloat(buffer)*sepeatorDistance - 2 * inset)
        
        let card = TDCardView(frame: frame, model: viewModel)
        card.delegate = self
        
        return card
    }
    
    fileprivate func animateCardAfterSwiping() {
        for (i, card) in self.loadedCards.enumerated() {
            UIView.animate(withDuration: 0.5, animations: {
                            card.isUserInteractionEnabled = i == 0 ? true : false
                            var frame = card.frame
                            frame.origin.y = inset + (CGFloat(i) * sepeatorDistance)
                            card.frame = frame
                        })
        }
    }
    
    func prepareView() {
        self.backgroundColor = UIColor.clear
    }
}

extension TDControlView : TDCardActionDelegate {
    func cardGoesLeft(viewModel: CardViewModel) {
        self.popCard()
        if case let CardViewModel.Real(model) = viewModel {
            self.dislikePublishRelay.accept(model)
        }
        
    }
    
    func cardGoesRight(viewModel: CardViewModel) {
        self.popCard()
        if case let CardViewModel.Real(model) = viewModel {
            self.likePublishRelay.accept(model)
        }
    }
}
