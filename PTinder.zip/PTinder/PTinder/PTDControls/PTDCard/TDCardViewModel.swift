//
//  TDCardViewModel.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation

enum CardViewModel {
    case Loading, Real(model: User)
}

