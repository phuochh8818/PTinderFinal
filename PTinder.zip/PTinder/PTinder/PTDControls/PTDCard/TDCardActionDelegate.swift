//
//  TDCardActionDelegate.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation

/// Delegate action to control view when card was swiped
protocol TDCardActionDelegate: class {
    func cardGoesLeft(viewModel: CardViewModel)
    func cardGoesRight(viewModel: CardViewModel)
}
