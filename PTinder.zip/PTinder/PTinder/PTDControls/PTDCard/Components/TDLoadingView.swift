//
//  TDLoadingView.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit
import SnapKit
import Rswift

/// Present for the  loading card when there is no card left on the queue
class TDLoadingView : TDContent {
    
    lazy var errorLabel: UILabel = {
        let v = UILabel()
        v.text = R.string.localizable.browseErrorLoadMore()
        v.font = UIFont.systemFont(ofSize: 12)
        v.textColor = R.color.color_onBackgroundHelper()
        v.textAlignment = .center
        return v
    }()
    
    override func prepareView() {
        self.addSubview(errorLabel)
        errorLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.left.equalTo(self.snp.left).inset(10)
            make.right.equalTo(self.snp.right).inset(10)
        }
    }
    
    
}
