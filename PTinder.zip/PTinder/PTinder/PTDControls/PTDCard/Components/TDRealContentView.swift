//
//  TDRealContentView.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit

class TDRealContentView : TDContent {
    
    lazy var titleLabel: UILabel = {
        let v = UILabel()
        v.text = "My name is"
        v.textColor = R.color.color_onBackgroundHelper()
        v.font = UIFont.systemFont(ofSize: 12)
        v.textAlignment = .center
        v.sizeToFit()
        
        return v
    }()
    
    lazy var descriptionLabel: UILabel = {
        let v = UILabel()
        v.text = [(user.name?.first ?? ""),(user.name?.last ?? "")].joined(separator: " ")
        v.textColor = R.color.color_onBackground()
        v.font = UIFont.boldSystemFont(ofSize: 15)
        v.textAlignment = .center
        v.sizeToFit()
        
        return v
    }()
    
    
    /// Contruct and hold reference to the first Tab Content
    lazy var firstPage: UIView = {
        let v = UIView()
        let avatarImageView = UIImageView(image: R.image.bg_noAvatar())
        self.addSubview(avatarImageView)
        avatarImageView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.width.equalTo(avatarImageView.snp.height)
            make.width.equalTo(120)
            make.centerX.equalTo(self.snp.centerX)
        }
        
        avatarImageView.layer.cornerRadius = 60
        avatarImageView.clipsToBounds = true
        
        if let thumbnail = self.user.picture?.medium, let url = URL(string: thumbnail) {
            avatarImageView.kf.setImage(with: url, placeholder: R.image.bg_noAvatar())
        }
        
        let line = UIView()
        line.backgroundColor = R.color.color_onBackground()?.withAlphaComponent(0.2)
        self.insertSubview(line, belowSubview: avatarImageView)
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.right.equalTo(self.snp.right)
            make.height.equalTo(1)
            make.top.equalTo(avatarImageView.snp.bottom).inset(20)
        }
        
        
        self.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.right.equalTo(self.snp.right)
            make.top.equalTo(avatarImageView.snp.bottom).offset(5)
        }
        
        self.addSubview(descriptionLabel)
        descriptionLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.right.equalTo(self.snp.right)
            make.top.equalTo(titleLabel.snp.bottom).offset(5)
        }
        
        
        return v
    }()
    
    
    /// Create the bottom navigation buttons
    /// - Parameter image: Button Image
    /// - Returns: the Button to insert
    func createNavigationButton(with image: UIImage) -> UIButton {
        let navButton = ActionButton()

        navButton.setImage(image.withTintColor(.darkGray, renderingMode: .alwaysOriginal), for: .normal)
        navButton.setImage(image.withTintColor(.green, renderingMode: .alwaysOriginal), for: .selected)
        navButton.imageView?.contentMode = .scaleAspectFit
        
        navButton.snp.makeConstraints { (make) in
            make.width.equalTo(20)
        }
        
        navButton.touchUp = { sender in
            self.selectedButton = sender
        }

        return navButton
    }
    
    
    /// Reference to button 1
    lazy var buttonUser : UIButton = {
        let v = createNavigationButton(with: R.image.ic_user()!)
        v.tag = 1
        v.accessibilityIdentifier = "User Tab"
        return v
    }()
    
    /// Reference to button 2
    lazy var buttonCalendar : UIButton = {
        let v = createNavigationButton(with: R.image.ic_calendar()!)
        v.tag = 2
         
        return v
    }()
    
    /// Reference to button 3
    lazy var buttonLocation : UIButton = {
        let v = createNavigationButton(with: R.image.ic_location()!)
        v.tag = 3

        return v
    }()
    
    /// Reference to button 4
    lazy var buttonPhone : UIButton = {
        let v = createNavigationButton(with: R.image.ic_phoneOutline()!)
        v.tag = 4

        return v
    }()
    
    /// Reference to button 5
    lazy var buttonPadLock : UIButton = {
        let v = createNavigationButton(with: R.image.ic_padlock()!)
        v.tag = 5

        return v
    }()
    
    /// Reference to bottom bar container
    lazy var bottomBar: UIStackView = {
        let v = UIStackView(arrangedSubviews: [buttonUser, buttonCalendar, buttonLocation, buttonPhone, buttonPadLock])
        
        v.axis = .horizontal
        v.distribution = .equalSpacing
        
        return v
    }()
    
    
    /// Hold model
    let user: User
    
    
    /// Construct the content view
    /// - Parameters:
    ///   - user: the person information model to display
    ///   - frame: the fixed frame of the contentView define by the parent view
    init(user: User, frame: CGRect) {
        self.user = user
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    /// Entry point to build tree view
    override func prepareView() {
        self.addSubview(firstPage)
        self.addSubview(bottomBar)
        self.addSubview(indicatorViewWrapper)

        
        firstPage.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalTo(self.bottomBar.snp.top)
        }
        
        bottomBar.snp.makeConstraints { (make) in
            make.height.equalTo(60)
            make.bottom.equalToSuperview().inset(5)
            make.left.equalToSuperview().inset(10)
            make.right.equalToSuperview().inset(10)
        }
        
        indicatorViewWrapper.snp.makeConstraints { (make) in
            make.height.equalTo(2)
            make.bottom.equalTo(bottomBar.snp.top)
            make.left.equalToSuperview().inset(10)
            make.right.equalToSuperview().inset(10)
        }
        
        self.selectedButton = buttonUser

    }
    
    lazy var indicatorViewWrapper: UIView = {
        let v = UIView()
        v.addSubview(indicatorView)
        
        return v
    }()
    
    lazy var indicatorView: UIView = {
        let frame = CGRect(x: 10, y: 0, width: 20, height: 2)
        let v = UIView(frame: frame)
        v.backgroundColor = .green
        
        return v
    }()
    
    
    /// Reference to the selected bottom  button
    private weak var selectedButton: UIButton? {
        didSet {
            oldValue?.isSelected = false
            selectedButton?.isSelected = true
            guard let selectedButton = self.selectedButton else { return }
            updateInfo(tag: selectedButton.tag)
        }
    }
    
    private func updateInfo(tag: Int) {
        switch tag {
        case 1:
            titleLabel.text = "My name is"
            descriptionLabel.text = [(user.name?.first ?? ""),(user.name?.last ?? "")].joined(separator: " ")
            
        case 2:
            titleLabel.text = "I was born on"
            descriptionLabel.text = user.dob?.date
        case 3:
            titleLabel.text = "I live in"
            descriptionLabel.text = [(user.location?.city ?? ""),(user.location?.country ?? "")].joined(separator: ", ")
        case 4:
            titleLabel.text = "My phone number is"
            descriptionLabel.text = user.phone
        case 5:
            titleLabel.text = "This is available only to PREMIUM"
            descriptionLabel.text = ""
        default:
            break
        }
        
        updateIndicatorPosition(tag: tag - 1)

        titleLabel.sizeToFit()
        descriptionLabel.sizeToFit()
    }
    
    func updateIndicatorPosition(tag: Int) {
        let space = (indicatorViewWrapper.frame.width - 20)/4
        let toRect = CGRect(x: CGFloat(tag) * space, y: 0, width: 20, height: 2)

        UIView.animate(withDuration: 0.3, animations: { [weak self] in
            self?.indicatorView.frame = toRect
        })
    }
}
