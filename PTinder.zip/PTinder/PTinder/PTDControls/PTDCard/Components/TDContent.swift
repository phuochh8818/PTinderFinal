//
//  TDContent.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit


/// All content on the card should be override this class
class TDContent : UIView {
    func prepareView() {}
}
