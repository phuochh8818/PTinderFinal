//
//  FavoriteListItemCell.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit
import Kingfisher
import Rswift

class FavoriteListItemCell: UITableViewCell {
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
  
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
    }
    
    var data : CDLikedUser? {
        didSet {
            guard let model = data else { return }
            
            self.textLabel?.text = model.firstName
            self.detailTextLabel?.text = model.lastName
            
            if let thumbnail = model.thumbnail, let url = URL(string: thumbnail) {
                self.imageView?.kf.setImage(with: url, placeholder: R.image.bg_noAvatar())
            }
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        self.imageView?.kf.cancelDownloadTask()
        self.imageView?.kf.setImage(with: URL(string: ""))
        self.imageView?.image = nil
    }
    
    class var reuseIdentifier: String {
        return "FavoriteListItemCell"
    }
}

class FavoriteListNoItemCell: UITableViewCell {
    class var reuseIdentifier: String {
        return "FavoriteListNoItemCell"
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
  
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        
        self.textLabel?.text = R.string.localizable.commonListNoItem()
    }
}
