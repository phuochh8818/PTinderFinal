//
//  FavoriteListViewController.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa
import RxAppState
import RxDataSources

class FavoriteListViewController: BaseViewController<FavoriteListViewModel> {
    
    required init(injecting _: FavoriteListViewControllerDependencyResolver) {
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    @Weaver(.registration)
    var viewModel: FavoriteListViewModel
    
    private lazy var tableView: UITableView = {
        let v = UITableView(frame: self.view.bounds, style: .plain)
        return v
    }()
    
    private var datasource: RxTableViewSectionedReloadDataSource<FavoriteListItemViewModels> = {
        let ds = RxTableViewSectionedReloadDataSource<FavoriteListItemViewModels>.init(
            configureCell: { (dataSource, tableView, indexPath, item) in
                switch(item) {
                case let .userCell(user):
                    let cell = tableView.dequeueReusableCell(withIdentifier: FavoriteListItemCell.reuseIdentifier, for: indexPath) as! FavoriteListItemCell
                    cell.data = user
                    cell.selectionStyle = .none
                    return cell
                    
                case .noItem:
                    let cell = tableView.dequeueReusableCell(withIdentifier: FavoriteListNoItemCell.reuseIdentifier, for: indexPath) as! FavoriteListNoItemCell
                    return cell
                }
            },
            canEditRowAtIndexPath: { _, _ in
                return true
            },
            canMoveRowAtIndexPath: { _, _ in
                return true
            }
        )
        return ds
    }()
    
    override func prepareUI() {
        
        self.navigationItem.title = R.string.localizable.mainFavorite()
        
        self.prepareTableView()
    }
    
    func prepareTableView() {
        tableView.accessibilityIdentifier = "FavoriteListViewController"
        
        let f = CGRect(x: 0, y: 0, width: self.tableView.frame.width, height: 0)
        self.tableView.tableHeaderView = UIView(frame: f)
        self.tableView.tableFooterView = UIView(frame: f)
        
        self.tableView.backgroundView = UIView(frame: self.tableView.bounds)
        self.tableView.backgroundColor = R.color.color_backgroundSecondary()
        self.tableView.separatorStyle = .none
        self.tableView.rowHeight = UITableView.automaticDimension
        
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        tableView.register(FavoriteListItemCell.self, forCellReuseIdentifier: FavoriteListItemCell.reuseIdentifier)
        tableView.register(FavoriteListNoItemCell.self, forCellReuseIdentifier: FavoriteListNoItemCell.reuseIdentifier)
    }
    
    override func performBinding() {
        let input = FavoriteListViewModel.Input(
            viewWillAppear: self.rx.viewWillAppear.mapToVoid().asDriverOnErrorJustComplete(),
            removeLike: self.tableView.rx.itemDeleted.asDriver()
        )
        
        let output = self.viewModel.transform(input: input)
        
        output.fetching
            .drive(onNext: { [unowned self] in self.showLoading(withStatus: $0) })
            .disposed(by: self.disposeBag)
        output.error
            .drive(onNext: { [unowned self] in self.handleError(error: $0) })
            .disposed(by: self.disposeBag)
        
        output.users.asObservable()
            .map {
                $0.count > 0 ? [FavoriteListItemViewModels(items: $0)] : [FavoriteListItemViewModels(items: [.noItem])]
            }
            .bind(to: self.tableView.rx.items(dataSource: self.datasource))
            .disposed(by: self.disposeBag)
        
        output.deleteUser.drive().disposed(by: self.disposeBag)
        
    }
    
}

extension FavoriteListViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 64
    }
}
