//
//  FavoriteListViewModel.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxSwift
import RxCocoa

class FavoriteListViewModel : BaseViewModel<FavoriteListViewModel.Input, FavoriteListViewModel.Output> {
    struct Input {
        let viewWillAppear: Driver<Void>
        let removeLike: Driver<IndexPath>
    }
    
    struct Output {
        let fetching: Driver<Bool>
        let error: Driver<Error>
        let users: Driver<[FavoriteListItemViewModel]>
        let deleteUser: Driver<Void>
    }
    
    @Weaver(.registration, type: AppServiceImpl.self)
    var appService: AppService
    
    let refreshTrigger = PublishRelay<Void>()
    
    init(injecting _: FavoriteListViewModelDependencyResolver) { }
    
    override func transform(input: Input) -> Output {
        let fetching = activityIndicator.asDriver()
        let errors = errorTracker.asDriver()
        
        let users = Driver.combineLatest(input.viewWillAppear, self.refreshTrigger.asDriverOnErrorJustComplete().startWith(()))
            .flatMapLatest {_ in
                return self.appService.getFavoriteUsers()
                    .map { $0.map { FavoriteListItemViewModel.userCell($0) } }
                    .trackActivity(self.activityIndicator)
                    .trackError(self.errorTracker)
                    .asDriverOnErrorJustComplete()
            }
        
        let deleteUser = input.removeLike.withLatestFrom(users) { (indexPath, items)  in
            (indexPath, items)
        }.flatMapLatest { (indexPath, items) in
            return Observable.deferred { () -> Observable<Void> in
                let item = items[indexPath.row]
                if case let FavoriteListItemViewModel.userCell(user) = item {
                    return self.appService.deleteUser(user: user)
                } else {
                    return Observable.error(AppError.commonError)
                }
            }
            .do(onNext: { [unowned self](_) in
                self.refreshTrigger.accept(())
            })
            .trackActivity(self.activityIndicator)
            .trackError(self.errorTracker)
            .asDriverOnErrorJustComplete()
        }
        
        return Output(fetching: fetching,
                      error: errors,
                      users: users,
                      deleteUser: deleteUser.mapToVoid()
        )
    }
}
