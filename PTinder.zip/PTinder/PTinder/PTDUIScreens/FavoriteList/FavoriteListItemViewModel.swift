//
//  FavoriteListItemViewModel.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxDataSources

enum FavoriteListItemViewModel {
    case userCell(CDLikedUser)
    case noItem
}

struct FavoriteListItemViewModels {
    var items: [FavoriteListItemViewModel]
}

extension FavoriteListItemViewModels: SectionModelType {
    init(original: FavoriteListItemViewModels, items: [FavoriteListItemViewModel]) {
        self = original
        self.items = items
    }
}
