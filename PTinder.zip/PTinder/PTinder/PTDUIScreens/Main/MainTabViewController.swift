//
//  MainTabViewController.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit
import Rswift

class MainTabViewController : UITabBarController {
    
    required init(injecting _: MainTabViewControllerDependencyResolver) {
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    @Weaver(.registration, type: BrowseViewController.self)
    @objc private var browseViewController: UIViewController
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setViewControllers([
                            UINavigationController(rootViewController: browseViewController),
                            UINavigationController(rootViewController: UIViewController())
                           ], animated: false)
        tabBar.items![0].title = R.string.localizable.mainBrowse()
        tabBar.items![0].selectedImage = R.image.ic_filter()?.withTintColor(.green, renderingMode: .alwaysOriginal)
        tabBar.items![0].image = R.image.ic_filter()?.withTintColor(.darkGray, renderingMode: .alwaysOriginal)
        
        tabBar.items![1].title = R.string.localizable.mainHistory()
        tabBar.items![1].selectedImage = R.image.ic_history()?.withTintColor(.green, renderingMode: .alwaysOriginal)
        tabBar.items![1].image = R.image.ic_history()?.withTintColor(.darkGray, renderingMode: .alwaysOriginal)
    }
    
}
