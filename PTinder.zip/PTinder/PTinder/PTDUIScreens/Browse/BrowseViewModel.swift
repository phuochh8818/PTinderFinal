//
//  BrowseViewModel.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxSwift
import RxCocoa

class BrowseViewModel : BaseViewModel<BrowseViewModel.Input, BrowseViewModel.Output> {
    struct Input {
        let viewFirstAppear: Driver<Void>
        let refreshTrigger: Driver<Void>
        let swipeLike: Driver<User>
    }
    
    struct Output {
        let fetching: Driver<Bool>
        let error: Driver<Error>
        let users: Driver<[User]>
        let likeUser: Driver<Void>
    }
    
    @Weaver(.registration, type: AppServiceImpl.self)
    var appService: AppService
    
    init(injecting _: BrowseViewModelDependencyResolver) {
        
    }
    
    override func transform(input: Input) -> Output {
        
        let fetching = activityIndicator.asDriver()
        let errors = errorTracker.asDriver()
        
        let users = Driver.combineLatest(input.viewFirstAppear, input.refreshTrigger.startWith(()))
            .flatMapLatest { _ in
                return self.appService.fetch50User()
                    .trackActivity(self.activityIndicator)
                    .trackError(self.errorTracker)
                    .asDriverOnErrorJustComplete()
        }
        
        let likeUser = input.swipeLike
            .flatMapLatest {
                return self.appService.addToFavorite(user: $0)
                    .trackActivity(self.activityIndicator)
                    .trackError(self.errorTracker)
                    .asDriverOnErrorJustComplete()
        }
        
        return Output(fetching: fetching,
                      error: errors,
                      users: users,
                      likeUser: likeUser
        )
    }
}
