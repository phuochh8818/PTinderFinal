//
//  BrowseViewController.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import UIKit
import RxAppState
import RxSwift
import RxCocoa

class BrowseViewController: BaseViewController<BrowseViewModel> {
    
    required init(injecting _: BrowseViewControllerDependencyResolver) {
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    @Weaver(.registration)
    var viewModel: BrowseViewModel
    
    @Weaver(.registration, type: FavoriteListViewController.self)
    @objc private var favoriteListViewController: UIViewController

    lazy var swipeView: TDControlView = {
        return TDControlView()
    }()
    
    lazy var refreshButton: UIBarButtonItem = {
        let v = UIBarButtonItem.init(systemItem: .refresh)
        return v
    }()
    
    lazy var favoriteButton: UIButton = {
        let v = createFavoriteButton(with: R.image.ic_heartRed()!)
        return v
    }()
    
    func createFavoriteButton(with image: UIImage) -> UIButton {
        let favButton = ActionButton()

        favButton.setImage(image.withTintColor(.red, renderingMode: .alwaysOriginal), for: .normal)

        favButton.imageView?.contentMode = .scaleAspectFit
        
        favButton.snp.makeConstraints { (make) in
            make.width.equalTo(20)
        }
        
        favButton.touchUp = { [unowned self] sender in
            self.navigationController?.pushViewController(self.favoriteListViewController, animated: true)
        }

        favButton.accessibilityIdentifier = "FavList"
        
        return favButton
    }
    
    /// Depend on type of screen.
    var cardHeight: CGFloat {
        return 500
    }

    override func prepareUI() {
        
        let bgImageView = UIView()
        bgImageView.backgroundColor = UIColor.init(patternImage: R.image.bg_sword()!)
        self.view.addSubview(bgImageView)
        bgImageView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bgImageView.alpha = 0.1

        self.view.addSubview(swipeView)
        swipeView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(50)
            make.right.equalToSuperview().inset(50)
            make.top.equalToSuperview().inset(200)
            make.height.equalTo(cardHeight)
        }
        
        self.navigationItem.setLeftBarButton(self.refreshButton, animated: false)
        
        let rightBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: favoriteButton)
        self.navigationItem.setRightBarButton(rightBarButtonItem, animated: false)
    }
    
    override func performBinding() {
        super.performBinding()
        
        let input = BrowseViewModel.Input(
            viewFirstAppear: self.rx.viewWillAppear.mapToVoid().take(1).asDriverOnErrorJustComplete(),
            refreshTrigger: self.refreshButton.rx.tap.asDriver(),
            swipeLike: self.swipeView.likePublishRelay.asDriverOnErrorJustComplete()
        )
        
        let output = self.viewModel.transform(input: input)
        
        output.fetching
            .drive(onNext: { [unowned self] in self.showLoading(withStatus: $0) })
            .disposed(by: self.disposeBag)
        
        output.error
            .drive(onNext: { [unowned self] in self.handleError(error: $0) })
            .disposed(by: self.disposeBag)
        
        output.users.asDriver().drive { [unowned self](users) in
            self.swipeView.loadMore(models: users)
        }.disposed(by: self.disposeBag)
            
        output.likeUser.drive { [unowned self] (_) in
            self.showToast(message: R.string.localizable.browseAddedToFavorites())
        }.disposed(by: self.disposeBag)


    }

}
