//
//  BaseViewController.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit
import RxSwift

class BaseViewController<VM>: AppBaseViewController {
    
    public func performBinding() { }
    
    override func prepareUI() { }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareUI()
        self.performBinding()
    }
    
    deinit {
        debugPrint("-------------------disposed--------------------")
    }
    
}
