//
//  BaseViewModel.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxSwift
import RxCocoa

public class BaseViewModel<Input, Output> {
    let activityIndicator = ActivityIndicator()
    let refreshActivityIndicator = ActivityIndicator()
    let errorTracker = ErrorTracker()

    public func transform(input: Input) -> Output {
        var o: Output!
        return o
    }
    
}
