//
//  AppBaseViewController.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit
import RxSwift
import MBProgressHUD
import Toast_Swift
import Rswift

class AppBaseViewController: UIViewController {
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        prepareUI()
    }
    
    func prepareUI() { }
    
    func showToast(message: String) {
        self.view.makeToast(message, duration: 3.0, position: .bottom)
    }
    
    func showLoading(withStatus show: Bool) {
        if show {
            let hud = MBProgressHUD.showAdded(to: self.view, animated: true)
            hud.mode = .indeterminate
            hud.label.text = R.string.localizable.commonLoading()
            hud.label.font = UIFont.systemFont(ofSize: 14)
        } else {
            MBProgressHUD.hide(for: self.view, animated: true)
        }
    }

    func handleError(error: Error) {
        self.displayError(error: error)
    }
    
    func displayError(error: Error) {
        switch error {
        default:
            self.showToast(message: error.localizedDescription)
        }
    }
    
    func hideKeyboard() {
        self.view.endEditing(true)
    }
    
}
