//
//  AppDelegate.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/14/20.
//

import UIKit
import CoreData

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    private let dependencies = MainDependencyContainer.appDelegateDependencyResolver()

    @Weaver(.registration, type: MainTabViewController.self)
        private var rootViewController: UIViewController

    @Weaver(.registration, type: AppServiceImpl.self, builder: AppDelegate.makeAppService)
        private var appService: AppService

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow()
        window?.rootViewController = rootViewController
        window?.makeKeyAndVisible()
        return true
    }
}

extension AppDelegate {
    static func makeAppService(_ dependencies: AppServiceImplDependencyResolver) -> AppService {
        return AppServiceImpl(injecting: dependencies)
    }
}

