//
//  AppDataRepository.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxSwift
import CoreData

protocol AppDataRepository {
    func getLikedUsers() -> Observable<[CDLikedUser]>
    func like(user: User) -> Observable<CDLikedUser>
    func delete(user: CDLikedUser) -> Observable<Void>
}

class AppDataRepositoryImpl : AppDataRepository {
    
    private let dependencies: AppDataRepositoryImplDependencyResolver
    
    // weaver: coreDataStack = CoreDataStack

    var context: NSManagedObjectContext {
        get {
            return self.dependencies.coreDataStack.mainContext
        }
    }

    init(injecting dependencies: AppDataRepositoryImplDependencyResolver) {
        self.dependencies = dependencies
    }
    
    func getLikedUsers() -> Observable<[CDLikedUser]> {
        do {
            let request: NSFetchRequest<CDLikedUser> = CDLikedUser.fetchRequest()
            let v = try self.context.fetch(request)
            return Observable.just(v)
        }
        catch {
            return Observable.error(error)
        }
    }
    
    func like(user: User) -> Observable<CDLikedUser> {
        do {
            guard let name = user.name else {
                return Observable.error(AppError.invalidData)
            }

            guard let thumbnail = user.picture?.thumbnail else {
                return Observable.error(AppError.invalidData)
            }
            
            let cdUser = CDLikedUser(context: context)
            cdUser.firstName = name.first
            cdUser.lastName = name.last
            cdUser.thumbnail = thumbnail
        
            context.insert(cdUser)
            try context.save()
            return Observable.just(cdUser)
        }
        catch {
            return Observable.error(error)
        }
    }
    
    func delete(user: CDLikedUser) -> Observable<Void> {
        do {
            context.delete(user)
            try context.save()
            return Observable.just(())
        }
        catch {
            return Observable.error(error)
        }
    }
}
