//
//  RandomUserRepository.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import Alamofire
import RxSwift

protocol RandomUserRepository {
    func get() -> Observable<[User]>
}

class RandomUserRepositoryImpl : RandomUserRepository {
    
    var sessionManager = Alamofire.Session.init()

    func get() -> Observable<[User]> {

        return Observable.create({ observer -> Disposable in
            self.sessionManager
                .request("https://randomuser.me/api/?results=50", method: .get).responseDecodable { (response: AFDataResponse<ResponseDto<User>>) in
                    switch response.result {
                    case .success(let value):
                        observer.onNext(value.results)
                        break
                    case .failure(let error):
                        observer.onError(AppError.APIResponseError(innerError: error))
                    }
                    observer.onCompleted()
                }
            return Disposables.create()
        })
    }
}
