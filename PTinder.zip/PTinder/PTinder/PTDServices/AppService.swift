//
//  AppService.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxSwift

protocol AppService {
    func fetch50User() -> Observable<[User]>
    func addToFavorite(user: User) -> Observable<Void>
    func getFavoriteUsers() -> Observable<[CDLikedUser]>
    func deleteUser(user: CDLikedUser) -> Observable<Void>
}

final class AppServiceImpl : AppService {
    
    private let dependencies: AppServiceImplDependencyResolver
    
    init(injecting dependencies: AppServiceImplDependencyResolver) {
        self.dependencies = dependencies
    }
    
    
    @Weaver(.registration, type: RandomUserRepositoryImpl.self)
    var repoRandomUser: RandomUserRepository
    
    @Weaver(.registration, type: AppDataRepositoryImpl.self)
    var repoAppData: AppDataRepository
    
    func fetch50User() -> Observable<[User]> {
        return self.repoRandomUser.get()
    }
    
    func addToFavorite(user: User) -> Observable<Void> {
        return self.repoAppData.like(user: user)
            .mapToVoid()
    }
    
    func getFavoriteUsers() -> Observable<[CDLikedUser]> {
        return self.repoAppData.getLikedUsers()
    }
    
    func deleteUser(user: CDLikedUser) -> Observable<Void> {
        return self.repoAppData.delete(user: user)
    }
}
