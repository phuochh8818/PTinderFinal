//
//  APIServiceError.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation

enum APIServiceError : Error {
    case ParseDataError(message: String)
}
