//
//  AppError.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation

enum AppError : Error {
    case APIResponseError(innerError: Error)
    case commonError
    case invalidData
}

