//
//  ResponseDto.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation

// MARK: - ResponseDto
public struct ResponseDto<R: Codable>: Codable {
    public let results: [R]
    public let info: Info

    public init(results: [R], info: Info) {
        self.results = results
        self.info = info
    }
}

// MARK: - Info
public struct Info: Codable {
    public let seed: String
    public let results, page: Int
    public let version: String

    public init(seed: String, results: Int, page: Int, version: String) {
        self.seed = seed
        self.results = results
        self.page = page
        self.version = version
    }
}
