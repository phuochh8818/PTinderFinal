//
//  User.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation

// MARK: - Result
public struct User: Codable {
    public let gender: String?
    public let name: Name?
    public let location: Location?
    public let email: String?
    public let login: Login?
    public let dob, registered: Dob?
    public let phone, cell: String?
    public let picture: Picture?
    public let nat: String?
}

// MARK: - Dob
public struct Dob: Codable {
    public let date: String
    public let age: Int
}

// MARK: - Location
public struct Location: Codable {
    public let street: Street
    public let city, state, country: String
    public let postcode: Postcode
    public let coordinates: Coordinates
    public let timezone: Timezone
}

public enum Postcode: Codable {
    case integer(Int)
    case string(String)

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let x = try? container.decode(Int.self) {
            self = .integer(x)
            return
        }
        if let x = try? container.decode(String.self) {
            self = .string(x)
            return
        }
        throw DecodingError.typeMismatch(Postcode.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for Postcode"))
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .integer(let x):
            try container.encode(x)
        case .string(let x):
            try container.encode(x)
        }
    }
}


// MARK: - Coordinates
public struct Coordinates: Codable {
    public let latitude, longitude: String

    public init(latitude: String, longitude: String) {
        self.latitude = latitude
        self.longitude = longitude
    }
}

// MARK: - Street
public struct Street: Codable {
    public let number: Int
    public let name: String
}

// MARK: - Timezone
public struct Timezone: Codable {
    public let offset, timezoneDescription: String

    enum CodingKeys: String, CodingKey {
        case offset
        case timezoneDescription = "description"
    }
}

// MARK: - Login
public struct Login: Codable {
    public let uuid, username, password, salt: String
    public let md5, sha1, sha256: String
}

// MARK: - Name
public struct Name: Codable {
    public let title, first, last: String
}

// MARK: - Picture
public struct Picture: Codable {
    public let large, medium, thumbnail: String
}
