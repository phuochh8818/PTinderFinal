//
//  ActionButton.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import UIKit

open class ActionButton: UIButton {
    var touchDown: ((_ button: UIButton) -> ())?
    var touchExit: ((_ button: UIButton) -> ())?
    var touchUp: ((_ button: UIButton) -> ())?

    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupButton()
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupButton()
    }
    
    func setupButton() {
        
        self.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        
        //this is my most common setup, but you can customize to your liking
        addTarget(self, action: #selector(touchDown(sender:)), for: [.touchDown, .touchDragEnter])
        addTarget(self, action: #selector(touchExit(sender:)), for: [.touchCancel, .touchDragExit])
        addTarget(self, action: #selector(touchUp(sender:)), for: [.touchUpInside])
    }
    
    //actions
    @objc func touchDown(sender: UIButton) {
        touchDown?(sender)
    }
    
    @objc func touchExit(sender: UIButton) {
        touchExit?(sender)
    }
    
    @objc func touchUp(sender: UIButton) {
        touchUp?(sender)
    }
}
