//
//  Queue.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

struct Queue<T> {
    private(set) var elements: [T] = []
    
    mutating func enqueue(_ value: T) {
        elements.append(value)
    }
    
    mutating func enqueue(contentsOf values: [T]) {
        elements.append(contentsOf: values)
    }
    
    mutating func dequeue() -> T? {
        guard !elements.isEmpty else {
            return nil
        }
        return elements.removeFirst()
    }
    
    var head: T? {
        return elements.first
    }
    
    var tail: T? {
        return elements.last
    }
}
