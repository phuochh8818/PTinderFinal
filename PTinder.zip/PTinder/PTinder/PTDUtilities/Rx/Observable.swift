//
//  Observable.swift
//  PTinder
//
//  Created by Huynh Hong Phuoc on 12/15/20.
//

import Foundation
import RxSwift
import RxCocoa

extension ObservableType where Element == Bool {
    /// Boolean not operator
    public func not() -> Observable<Bool> {
        return self.map(!)
    }
    
}

extension SharedSequenceConvertibleType {
    public func mapToVoid() -> SharedSequence<SharingStrategy, Void> {
        return map { _ in }
    }
}

extension ObservableType {
    
    public func asDriverOnErrorJustComplete() -> Driver<Element> {
        return asDriver { error in
            debugPrint("Error \(error)")
            return Driver.empty()
        }
    }
    
    public func mapToVoid() -> Observable<Void> {
        return map { _ in }
    }
    
    public func debug(_ identifier: String = "default", trimOutput: Bool = true, file: String = #file, line: UInt = #line, function: String = #function, enable: Bool)
        -> Observable<Element> {
            if (enable) {
                return self.debug(identifier, trimOutput: trimOutput)
            }
            
            return self.asObservable()
    }

}
